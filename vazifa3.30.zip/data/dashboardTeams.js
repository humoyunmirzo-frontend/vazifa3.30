export const teams = {
    labels: ['a', 'b', 'c', 'd'],
    data: [1, 5, 3, 10]
}
