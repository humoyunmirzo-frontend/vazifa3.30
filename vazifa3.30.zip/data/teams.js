export const teams = [
    {
        name: "designers",
        slug: "designer",
        members: [
            {
                img: require("../assets/images/Rectangle 774.png"),
                name: 'Adam',
                groupName: "Designers"
            },
            {
                img: require("../assets/images/Rectangle 774 (1).png"),
                name: 'Robert',
                groupName: "Designers"
            },
            {
                img: require("../assets/images/Rectangle 774 (2).png"),
                name: 'Adam',
                groupName: "Designers"
            },
            {
                img: require("../assets/images/Rectangle 774.png"),
                name: 'Jack',
                groupName: "Designers"
            },
            {
                img: require("../assets/images/Rectangle 774 (1).png"),
                name: 'Robert',
                groupName: "Designers"
            }
        ]
    },
    {
        name: "developers",
        slug: "developer",
        members: [
            {
                img: require("../assets/images/Rectangle 774 (2).png"),
                name: 'Robert',
                groupName: "Developers"
            },
            {
                img: require("../assets/images/Rectangle 774.png"),
                name: 'Adam',
                groupName: "Developers"
            },
            {
                img: require("../assets/images/Rectangle 774 (1).png"),
                name: 'Jack',
                groupName: "Developers"
            },
            {
                img: require("../assets/images/Rectangle 774 (2).png"),
                name: 'Robert',
                groupName: "Developers"
            }
        ]
    }
]
