export const teams = {
    labels: ['a', 'b', 'c', 'd'],
    data: [1, 5, 3, 10]
}
export const projects = {
    labels: ['Oct 2021', 'Nov 2021', 'Dec 2021', 'Jan 2021', 'Feb 2021', 'Mar 2021',],
    data1: [6, 7, 6.5, 4.5, 7.9, 5.9, 6.4, 6],
    data2: [3.9, 3.5, 6, 5.8, 3.5, 4.5, 4.8, 6.3, 5.5, 5.8, 5]
}